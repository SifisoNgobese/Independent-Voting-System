﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class RegisterPage : Form
    {
        //======================================variable decleration =======================================================
        public string IDNumber = "", firstName = "", middleName = "", lastName = "", gender = "", title = "", StreetName = "", Surburb = "", Province = "", PostalCode = "", emailAdress = "", CellNumber = "";
        public int houseNumber = 0;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlCommand command2 = new SqlCommand();
        SqlDataAdapter adapter2 = new SqlDataAdapter();
        DataSet DS = new DataSet();
        SqlCommand SELCECTcommand = new SqlCommand();

        public string Password = "";

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            //======================================error message if the user enters a
            if (txtFirstName.Text != "" && !txtFirstName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please dont enter numbers in this field","Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFirstName.Text = "";
                
            }
            else
            {
            }
        }

        private void txtHouseNumber_TextChanged(object sender, EventArgs e)
        {
            if (txtHouseNumber.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please  enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHouseNumber.Text = "";

            }
            else
            {


            }
        }

        private void txtStreetName_TextChanged(object sender, EventArgs e)
        {

            if (!txtStreetName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please dont enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStreetName.Text = "";

            }
            else
            {


            }
        }

        private void txtSurburb_TextChanged(object sender, EventArgs e)
        {
            if (!txtSurburb.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please dont enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSurburb.Text = "";

            }
            else
            {


            }
        }

        private void txtPostalCode_TextChanged(object sender, EventArgs e)
        {
            if (txtPostalCode.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPostalCode.Text = "";

            }
            else
            {


            }
        }

        private void txtMiddleName_TextChanged(object sender, EventArgs e)
        {
            if (!txtMiddleName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please dont enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMiddleName.Text = "";

            }
            else
            {


            }
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            if (!txtLastName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Please dont enter numbers in this field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLastName.Text = "";

            }
            else
            {


            }
        }

        public string sqlcommand, sqlcommand2;
        public string chosenLanguage;


        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {

            try
            {
                //=============================input validation for idnumber textbox===============================================
                string input = txtIDNumber.Text;
                if (input.Length == 13)
                {
                    int birthYear = int.Parse(input.Substring(0, 2));
                    int birthMonth = int.Parse(input.Substring(2, 2));
                    int birthDay = int.Parse(input.Substring(4, 2));

                    DateTime birthDate = new DateTime();
                    if (birthYear < 23)
                    {
                        birthDate = new DateTime(2000 + birthYear, birthMonth, birthDay);
                    }
                    else if (birthYear >= 23)
                    {
                        birthDate = new DateTime(1900 + birthYear, birthMonth, birthDay);

                    }


                    int age = DateTime.Now.Year - birthDate.Year;
                    if (DateTime.Now.Month < birthDate.Month || (DateTime.Now.Month == birthDate.Month && DateTime.Now.Day < birthDate.Day))
                    {
                        age--;
                    }

                    if (age >= 18)
                    {
                        txtIDNumber.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        txtIDNumber.ForeColor = System.Drawing.Color.Red;
                    }
                }
                else
                {
                    txtIDNumber.ForeColor = System.Drawing.Color.Red;
                    
                }

                connection.Close();
            }
            catch
            {
                MessageBox.Show("invalid ID number", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIDNumber.Text = "";
            }


            try
            {
                connection.Open();

                string selectCommand = $"SELECT * FROM Voters WHERE IDNumber = @IDNumber";
                SqlCommand sqlCommand = new SqlCommand(selectCommand, connection);

                sqlCommand.Parameters.AddWithValue("@IDNumber", txtIDNumber.Text);

                SqlDataReader reader = sqlCommand.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("The ID number has already been registered.");
                    txtIDNumber.Text = "";
                }
                else
                {
                    
                }

                connection.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }


        private void txtCellPhoneNumber_TextChanged(object sender, EventArgs e)
        {
        //================================input validate phone number==================================
            string inputNumber = txtCellPhoneNumber.Text.Trim();

            string pattern = @"^\+27\d{9}$";

            if (Regex.IsMatch(inputNumber, pattern))
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Green;
                BtnConfirm.Enabled = true;
                lblNumbererror.Visible = false;
            }
            else
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Red;
                BtnConfirm.Enabled = false;
                lblNumbererror.Visible = true;
                lblNumbererror.Text = "the number you have entered us incorrect please ensure that it starts with +27 and is the right length ";
            }
        }

        private void lblhousenumber_Click(object sender, EventArgs e)
        {

        }

       

        

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            //==============================================input validation for email====================================================
            string emailPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            if (Regex.IsMatch(txtEmail.Text, emailPattern))
            {
                txtEmail.ForeColor = System.Drawing.Color.Green; 
            }
            else
            {
                txtEmail.ForeColor = System.Drawing.Color.Red;
            }
        }

        
        public RegisterPage(string language)
        {
            InitializeComponent();
            //fetch variables from other form 
            chosenLanguage = language;      
        }

       

        private void BtnBack_Click(object sender, EventArgs e)
        {
            //=========================================================goes back to the home page==============================================
            frmWelcomePage welcomePage = new frmWelcomePage();
            welcomePage.Show();
            this.Hide();
            chosenLanguage = "";
            listBox1.Items.Clear();

        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            //============================================iif none of the text boxes are empty the the code will insert the user data to the voters table=========================================================
            if (txtCellPhoneNumber.Text != null && txtConfirmPassword.Text != null && txtEmail.Text != null && txtFirstName.Text != null && txtHouseNumber.Text != null && txtIDNumber.Text != null && txtLastName.Text != null && txtMiddleName.Text != null && txtPassword.Text != null && txtPostalCode.Text != null && txtStreetName.Text != null && txtSurburb.Text != null)
            {
                try
                {
                    connection.Close();
                    connection.Open();
                    sqlcommand = $"INSERT INTO Voters  VALUES ('{txtIDNumber.Text}','{txtFirstName.Text}','{txtLastName.Text}','{txtMiddleName.Text}','{txtHouseNumber.Text}','{txtStreetName.Text}','{txtSurburb.Text}','{cbProvince.Text}','{txtPostalCode.Text}','{txtEmail.Text}','{txtCellPhoneNumber.Text}','{txtPassword.Text}','{cbTitle.Text}')";
                    command = new SqlCommand(sqlcommand, connection);
                    adapter.InsertCommand = command;
                    adapter.InsertCommand.ExecuteNonQuery();
                    listBox1.Items.Clear();
                    MessageBox.Show("You have successfully registered");
                    connection.Close();


                    //========================takes user straight to the login form============================================
                    frmWelcomePage welcomePage = new frmWelcomePage();
                    welcomePage.Show();
                    this.Hide();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            

        }

        
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //store textbox values in the variables
                int.TryParse(txtHouseNumber.Text, out houseNumber);
                IDNumber = txtIDNumber.Text;
                firstName = txtFirstName.Text;
                lastName = txtLastName.Text;
                middleName = txtMiddleName.Text;
                StreetName = txtStreetName.Text;
                Surburb = txtSurburb.Text;
                Province = cbProvince.Text;
                PostalCode = txtPostalCode.Text;
                emailAdress = txtEmail.Text;
                CellNumber = txtCellPhoneNumber.Text;
                title = cbTitle.Text;
                gender = CbGender.Text;
                Password = txtPassword.Text;

                //list box showing the users details
                listBox1.Items.Add("Your details are as follows");
                listBox1.Items.Add(" ");
                listBox1.Items.Add("Title:" + "\t\t" + title);
                listBox1.Items.Add("Gender:" + "\t\t" + gender);
                listBox1.Items.Add("ID Number: " + "\t" + IDNumber);
                listBox1.Items.Add("First name: " + "\t" + firstName);
                listBox1.Items.Add("Middle name: " + "\t" + middleName);
                listBox1.Items.Add("Last name: " + "\t" + lastName);
                listBox1.Items.Add("House Number: " + "\t" + houseNumber);
                listBox1.Items.Add("Street Name: " + "\t" + StreetName);
                listBox1.Items.Add("Surburb: " + "\t\t" + Surburb);
                listBox1.Items.Add("Province: " + "\t" + Province);
                listBox1.Items.Add("Postal Code: " + "\t" + PostalCode);
                listBox1.Items.Add("Email Address:" + "\t" + emailAdress);
                listBox1.Items.Add("Cellphone Number: " + "\t" + CellNumber);

                if (txtConfirmPassword.Text != txtPassword.Text)
                {
                    MessageBox.Show("The passwords do not match!");
                    txtPassword.Text = " ";
                    txtConfirmPassword.Text = " ";
                }
                else if (txtPassword.TextLength < 8)
                {
                    MessageBox.Show("Password is less than 8 characters");
                }
                else
                {
                    BtnConfirm.Visible = true;
                    BtnRegister.Visible = false;
                }

            }
            catch (Exception ex)
            { 
                //if theres an error in the code we will know what the error is because it will be shown in a message box
                MessageBox.Show(ex.Message);
            }
            

        }









        private void RegisterPage_Load(object sender, EventArgs e)
        {
            BtnConfirm.Visible = false;

            //================================================sesotho language==================================================== 
            if (chosenLanguage == "sesotho")
            {
                lblheading.Text = "IVC LEPHEPHE LA NGODISO";

                groupBox1.Text = "disntla tse di amanang le uena";
                lbltitle.Text = "Sehlooho:";
                lblGender.Text = "Bong";
                lblFirstName.Text = "Lebitso la Pele: ";
                lblLastName.Text = "fane";
                lblMiddleName.Text = "Lebitso la Gare:";

                gbContactInfromation.Text = "Aterese ea Sebaka";
                lblStreetname.Text = "Nomoro ea Ntlo:";
                lblStreetname.Text = "Lebisto la seterata:";
                lblSurburb.Text = "Toropo:";
                lblProvicnce.Text = "Profinse:";
                lblPostalcode.Text = "Nomora ea Poso:";

                gbContactInfromation.Text = "Dintlha tsa mohala";
                lblemail.Text = "Aterese ea Imeile:";
                lblCellphone.Text = "Nomoro ea Mohala(+27):";

                GbPhysicalAdress.Text = "Dintlha tsa ho kena";
                lblIDNumber.Text = "Nomoro ea ID:";
                LblPassword.Text = "Phasewete";
                lblConfirmPassword.Text = "Netefatsa Phasewete";

                BtnBack.Text = "morao";
                BtnRegister.Text = "ngodisa";
            }
            else if (chosenLanguage == "afrikaans")
            {
                lblheading.Text = "IVC REGISTEREER BLADSY";

                groupBox1.Text = "Personlik inligting";
                lbltitle.Text = "Titel:";
                lblGender.Text = "Geslag";
                lblFirstName.Text = "Eerste Naam: ";
                lblLastName.Text = "Laaste Naam";
                lblMiddleName.Text = "Middel Naam:";

                gbContactInfromation.Text = "Kontak Inligting";
                lblStreetname.Text = "Straat Nommer:";
                lblStreetname.Text = "Straat Naam:";
                lblSurburb.Text = "Dorp:";
                lblProvicnce.Text = "Profinsie:";
                lblPostalcode.Text = "Poskode:";

                gbContactInfromation.Text = "Kontak Inligting";
                lblemail.Text = "E-Pos Adres:";
                lblCellphone.Text = "Selfoon Nommer(+27):";

                GbPhysicalAdress.Text = "Teken AanInligting";
                lblIDNumber.Text = "ID Nommer:";
                LblPassword.Text = "Wagwoord:";
                lblConfirmPassword.Text = "Bevestig wagwoord";

                BtnBack.Text = "Terug";
                BtnRegister.Text = "Registereer";
            }

            //=================================================Zulu language =================================================
            else if (chosenLanguage == "isiZulu")
            {

            }

            else
                    {
                //============================================default language is english =================================================================
                lblheading.Text = "IVC REGISTERATION PAGE";

                groupBox1.Text = "Physical Adress";
                lbltitle.Text = "Title:";
                lblGender.Text = "Gender:";
                lblFirstName.Text = "First Name: ";
                lblLastName.Text = "Last Name: ";
                lblMiddleName.Text = "Middle Name:";

                GbPhysicalAdress.Text = "Physical Adress";
                lblStreetname.Text = "Street Name: ";
                lblSurburb.Text = "Surburb/Town: ";
                lblProvicnce.Text = "Province:";
                lblPostalcode.Text = "Postal code:";

                gbContactInfromation.Text = "Contact information";
                lblemail.Text = "email adress:";
                lblCellphone.Text = "Cellphone number(+27):";

                GbPhysicalAdress.Text = "Physical adress";
                lblIDNumber.Text = "ID Number:";
                LblPassword.Text = "Password:";
                lblConfirmPassword.Text = "Confirm Password";

                BtnBack.Text = "Back";
                BtnRegister.Text = "Register";
            }

            try
            {
                connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30");
                connection.Open();
                connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
