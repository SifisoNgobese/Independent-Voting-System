﻿namespace Group23Project_IndependentVotingCommision.Properties
{
    partial class FrmBallot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBallot));
            this.btnLogOut = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirmVote = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblEFF = new System.Windows.Forms.Label();
            this.radioEFF = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.lblDA = new System.Windows.Forms.Label();
            this.radioDA = new System.Windows.Forms.RadioButton();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lblANC = new System.Windows.Forms.Label();
            this.radioANC = new System.Windows.Forms.RadioButton();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.lblTADA = new System.Windows.Forms.Label();
            this.radioTADA = new System.Windows.Forms.RadioButton();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblACDP = new System.Windows.Forms.Label();
            this.radioABDP = new System.Windows.Forms.RadioButton();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.lblUDM = new System.Windows.Forms.Label();
            this.radioUDM = new System.Windows.Forms.RadioButton();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogOut
            // 
            resources.ApplyResources(this.btnLogOut, "btnLogOut");
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // btnConfirmVote
            // 
            resources.ApplyResources(this.btnConfirmVote, "btnConfirmVote");
            this.btnConfirmVote.Name = "btnConfirmVote";
            this.btnConfirmVote.UseVisualStyleBackColor = true;
            this.btnConfirmVote.Click += new System.EventHandler(this.btnConfirmVote_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            resources.ApplyResources(this.listBox1, "listBox1");
            this.listBox1.Name = "listBox1";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // lblEFF
            // 
            resources.ApplyResources(this.lblEFF, "lblEFF");
            this.lblEFF.Name = "lblEFF";
            // 
            // radioEFF
            // 
            resources.ApplyResources(this.radioEFF, "radioEFF");
            this.radioEFF.Name = "radioEFF";
            this.radioEFF.TabStop = true;
            this.radioEFF.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // listBox6
            // 
            this.listBox6.FormattingEnabled = true;
            resources.ApplyResources(this.listBox6, "listBox6");
            this.listBox6.Items.AddRange(new object[] {
            resources.GetString("listBox6.Items")});
            this.listBox6.Name = "listBox6";
            // 
            // pictureBox11
            // 
            resources.ApplyResources(this.pictureBox11, "pictureBox11");
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.TabStop = false;
            // 
            // lblDA
            // 
            resources.ApplyResources(this.lblDA, "lblDA");
            this.lblDA.Name = "lblDA";
            // 
            // radioDA
            // 
            resources.ApplyResources(this.radioDA, "radioDA");
            this.radioDA.Name = "radioDA";
            this.radioDA.TabStop = true;
            this.radioDA.UseVisualStyleBackColor = true;
            // 
            // pictureBox12
            // 
            resources.ApplyResources(this.pictureBox12, "pictureBox12");
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.TabStop = false;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            resources.ApplyResources(this.listBox3, "listBox3");
            this.listBox3.Name = "listBox3";
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // lblANC
            // 
            resources.ApplyResources(this.lblANC, "lblANC");
            this.lblANC.Name = "lblANC";
            // 
            // radioANC
            // 
            resources.ApplyResources(this.radioANC, "radioANC");
            this.radioANC.Name = "radioANC";
            this.radioANC.TabStop = true;
            this.radioANC.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            resources.ApplyResources(this.pictureBox6, "pictureBox6");
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.TabStop = false;
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            resources.ApplyResources(this.listBox4, "listBox4");
            this.listBox4.Name = "listBox4";
            // 
            // pictureBox7
            // 
            resources.ApplyResources(this.pictureBox7, "pictureBox7");
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.TabStop = false;
            // 
            // lblTADA
            // 
            resources.ApplyResources(this.lblTADA, "lblTADA");
            this.lblTADA.Name = "lblTADA";
            // 
            // radioTADA
            // 
            resources.ApplyResources(this.radioTADA, "radioTADA");
            this.radioTADA.Name = "radioTADA";
            this.radioTADA.TabStop = true;
            this.radioTADA.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            resources.ApplyResources(this.pictureBox8, "pictureBox8");
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.TabStop = false;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            resources.ApplyResources(this.listBox2, "listBox2");
            this.listBox2.Name = "listBox2";
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // lblACDP
            // 
            resources.ApplyResources(this.lblACDP, "lblACDP");
            this.lblACDP.Name = "lblACDP";
            // 
            // radioABDP
            // 
            resources.ApplyResources(this.radioABDP, "radioABDP");
            this.radioABDP.Name = "radioABDP";
            this.radioABDP.TabStop = true;
            this.radioABDP.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            resources.ApplyResources(this.listBox5, "listBox5");
            this.listBox5.Name = "listBox5";
            // 
            // pictureBox9
            // 
            resources.ApplyResources(this.pictureBox9, "pictureBox9");
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.TabStop = false;
            // 
            // lblUDM
            // 
            resources.ApplyResources(this.lblUDM, "lblUDM");
            this.lblUDM.Name = "lblUDM";
            // 
            // radioUDM
            // 
            resources.ApplyResources(this.radioUDM, "radioUDM");
            this.radioUDM.Name = "radioUDM";
            this.radioUDM.TabStop = true;
            this.radioUDM.UseVisualStyleBackColor = true;
            // 
            // pictureBox10
            // 
            resources.ApplyResources(this.pictureBox10, "pictureBox10");
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.TabStop = false;
            // 
            // FrmBallot
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.lblUDM);
            this.Controls.Add(this.radioUDM);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lblACDP);
            this.Controls.Add(this.radioABDP);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.lblTADA);
            this.Controls.Add(this.radioTADA);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.lblANC);
            this.Controls.Add(this.radioANC);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.listBox6);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.lblDA);
            this.Controls.Add(this.radioDA);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblEFF);
            this.Controls.Add(this.radioEFF);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnConfirmVote);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.panel1);
            this.Name = "FrmBallot";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmBallot_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConfirmVote;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblEFF;
        private System.Windows.Forms.RadioButton radioEFF;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label lblDA;
        private System.Windows.Forms.RadioButton radioDA;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblANC;
        private System.Windows.Forms.RadioButton radioANC;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label lblTADA;
        private System.Windows.Forms.RadioButton radioTADA;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblACDP;
        private System.Windows.Forms.RadioButton radioABDP;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label lblUDM;
        private System.Windows.Forms.RadioButton radioUDM;
        private System.Windows.Forms.PictureBox pictureBox10;
    }
}