﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Group23Project_IndependentVotingCommision.Properties;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;

namespace Group23Project_IndependentVotingCommision
{
    
      


    public partial class LoginPage : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable dt = new DataTable();

        public string name, password, sqlcommand;
        public string ID_BallotForm { get; set; }
        public LoginPage()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmWelcomePage welcomePage = new frmWelcomePage();
            welcomePage.Show();
            this.Hide();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            ID_BallotForm = txtIdentificationNumber.Text;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtIdentificationNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
            {


                try
                {
                    connection.Open();


                    sqlcommand = @"SELECT * FROM Voters where IDNumber ='" + txtIdentificationNumber.Text + "' AND Password = '" + txtPassword.Text + "'";
                    adapter = new SqlDataAdapter(sqlcommand, connection);
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        name = txtIdentificationNumber.Text;
                        password = txtPassword.Text;

                        FrmBallot ballot = new FrmBallot(ID_BallotForm);
                        ballot.Show();
                        this.Hide();
                        password = "";
                        name = "";
                    }
                    else
                    {
                        MessageBox.Show("invalid user details", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtPassword.Clear();
                        txtIdentificationNumber.Clear();

                        txtIdentificationNumber.Focus();
                    }


                    connection.Close();
                }
                catch
                {

                }
            }

            private void LoginPage_Load(object sender, EventArgs e)
            {
                try
                {
                    connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30");
                    connection.Open();
                    connection.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
