﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class FrmStatistics : Form
    {
        public string sqlcommand;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet Ds = new DataSet();
        

        public FrmStatistics()
        {
            InitializeComponent();
        }

        private void FrmStatistics_Load(object sender, EventArgs e)
        {
            try
            {
                
                connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30");
                connection.Open();
                sqlcommand = "SELECT VotesRecorded.BallotID, VotesRecorded.VoterID,Voters.FirstName, Voters.LastName, Voters.Province, VotesRecorded.PartyVoted FROM VotesRecorded INNER JOIN Voters ON VotesRecorded.VoterID = Voters.IDNumber";
                command = new SqlCommand(sqlcommand, connection);

                adapter.SelectCommand = command;
                adapter.Fill(Ds, "Voters, VotesRecorded");

                dataGridView1.DataSource = Ds;
                dataGridView1.DataMember = "Voters, VotesRecorded";

                connection.Close();

                lbVotes.Items.Add("Independent Voting Commission Statitics");
                lbVotes.Items.Add("");
                lbVotes.Items.Add("");
                lbVotes.Items.Add("Political Parties" + "\t" + "Number Of Votes");
                lbVotes.Items.Add("");
                lbVotes.Items.Add("ANC" + "\t" + "");
                lbVotes.Items.Add("EFF" + "\t" + "");
                lbVotes.Items.Add("DA" + "\t" + "");
                lbVotes.Items.Add("UDM" + "\t" + "");
                lbVotes.Items.Add("TADA" + "\t" + "");
                lbVotes.Items.Add("ACDP" + "\t" + "");
                lbVotes.Items.Add("");
                lbVotes.Items.Add("TOTAL NUMBER OF VOTES:" + "\t" + "");

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {

                //Count total number of votes.
                string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    connection.Open();
                    string sql = "SELECT COUNT(*) FROM Voters WHERE";
                }

            }
             catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void rbAscending_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                //Sort the votes in ascending order.
                dataGridView1.Sort(dataGridView1.Columns[2], ListSortDirection.Ascending);
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void rbDescending_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                //Sort the votes in descending order.
                dataGridView1.Sort(dataGridView1.Columns[2], ListSortDirection.Descending);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
