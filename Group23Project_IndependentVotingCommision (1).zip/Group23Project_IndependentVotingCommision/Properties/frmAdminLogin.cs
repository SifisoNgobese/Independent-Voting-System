﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class frmAdminLogin : Form
    {
        public frmAdminLogin()
        {
            InitializeComponent();
        }

        private void frmAdminLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //USER NAME AND PASSWORD 
            if (txtUserName.Text == "IVC Admin" && txtPassword.Text == "IVC2023")
            {
                FrmStatistics statistics = new FrmStatistics();
                statistics.Show();
                this.Hide();
            }
            else
            {
                //INVALID LOGIN GIVES ERROR MESSAGE
                MessageBox.Show("invalid login details please try again");
                txtPassword.Text = "";
                txtUserName.Text = "";
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmWelcomePage welcomePage = new frmWelcomePage();
            welcomePage.Show();
            this.Hide();
        }
    }
}
