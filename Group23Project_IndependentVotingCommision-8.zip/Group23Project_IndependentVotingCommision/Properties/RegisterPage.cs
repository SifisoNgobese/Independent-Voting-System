﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class RegisterPage : Form
    {
        //remember to put in vote in the vote database
        public string IDNumber = "", firstName = "", middleName = "", lastName = "", gender = "", title = "", StreetName = "", Surburb = "", Province = "", PostalCode = "", emailAdress = "", CellNumber = "";
        public int houseNumber = 0;

        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {
            //=============================no clue what this does its done by Delilah thou===============================================
            string idNumber = txtIDNumber.Text;

            if (idNumber.Length >= 2 && int.TryParse(idNumber.Substring(0, 2), out int birthYearFirstTwoDigits))
            {
                int birthYear = 2000 + birthYearFirstTwoDigits; // Assuming the ID contains a two-digit year (e.g., YY)
                int age = CalculateAge(birthYear);

                if (age >= 18 && idNumber.Length == 13)
                {
                    txtIDNumber.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    txtIDNumber.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
        //=======================================Function for calculating the age=========================================================
        private int CalculateAge(int birthYear)
        {
            int currentYear = DateTime.Today.Year;
            int age = currentYear - birthYear;

            return age;
        }

        private void txtCellPhoneNumber_TextChanged(object sender, EventArgs e)
        {
        //================================validate phone number==================================
        //remember to add code to stop user from proceeding when the number is wrong 
            string inputNumber = txtCellPhoneNumber.Text.Trim();

            string pattern = @"^\+27\d{9}$";

            if (Regex.IsMatch(inputNumber, pattern))
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Green;
                BtnConfirm.Enabled = true;
                lblerror.Visible = false;
            }
            else
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Red;
                BtnConfirm.Enabled = false;
                lblerror.Text = "the number you have entered us incorrect please ensure that it starts with +27 and is the right length ";
            }
        }

        private void lblhousenumber_Click(object sender, EventArgs e)
        {

        }

       

        public string Password = "";

        public string sqlcommand, sqlcommand2;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();

        SqlCommand command2 = new SqlCommand();
        SqlDataAdapter adapter2 = new SqlDataAdapter();

        public string chosenLanguage;
        public RegisterPage(string language)
        {
            InitializeComponent();
            chosenLanguage = language;
            
        }

       

        private void BtnBack_Click(object sender, EventArgs e)
        {
            frmWelcomePage welcomePage = new frmWelcomePage();
            welcomePage.ShowDialog();
            this.Hide();
            chosenLanguage = "";
            listBox1.Items.Clear();

            //hide forms


        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
                if (txtCellPhoneNumber.Text != null && txtConfirmPassword.Text != null && txtEmail.Text != null && txtFirstName.Text != null && txtHouseNumber.Text != null && txtIDNumber.Text != null && txtLastName.Text != null && txtMiddleName.Text != null && txtPassword.Text != null && txtPostalCode.Text != null && txtStreetName.Text != null && txtSurburb.Text != null)
            {
                try
                {
                    //inserting into the voters database
                    connection.Close();
                    connection.Open();
                    sqlcommand = $"INSERT INTO Voters  VALUES ('{txtIDNumber.Text}','{txtFirstName.Text}','{txtLastName.Text}','{txtMiddleName.Text}','{txtHouseNumber.Text}','{txtStreetName.Text}','{txtSurburb.Text}','{cbProvince.Text}','{txtPostalCode.Text}','{txtEmail.Text}','{txtCellPhoneNumber.Text}','{txtPassword.Text}','{cbTitle.Text}')";
                    command = new SqlCommand(sqlcommand, connection);
                    adapter.InsertCommand = command;
                    adapter.InsertCommand.ExecuteNonQuery();
                    listBox1.Items.Clear();
                    MessageBox.Show("You have successfully registered");
                    connection.Close();


                    //inserting into the votesRecorded

                    

                    LoginPage loginPage = new LoginPage();
                    loginPage.Show();
                    this.Hide();
                }
                catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            

        }

        
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //store textbox values in the variables
                int.TryParse(txtHouseNumber.Text, out houseNumber);
                IDNumber = txtIDNumber.Text;
                firstName = txtFirstName.Text;
                lastName = txtLastName.Text;
                middleName = txtMiddleName.Text;
                StreetName = txtStreetName.Text;
                Surburb = txtSurburb.Text;
                Province = cbProvince.Text;
                PostalCode = txtPostalCode.Text;
                emailAdress = txtEmail.Text;
                CellNumber = txtCellPhoneNumber.Text;
                title = cbTitle.Text;
                gender = CbGender.Text;
                Password = txtPassword.Text;

                //list box showing the users details
                listBox1.Items.Add("Your details are as follows");
                listBox1.Items.Add(" ");
                listBox1.Items.Add("Title:" + "\t" + title);
                listBox1.Items.Add("Gender:" + "\t" + gender);
                listBox1.Items.Add("ID Number: " + "\t" + IDNumber);
                listBox1.Items.Add("First name: " + "\t" + firstName);
                listBox1.Items.Add("Middle name: " + "\t" + middleName);
                listBox1.Items.Add("Last name: " + "\t" + lastName);
                listBox1.Items.Add("House Number: " + "\t" + houseNumber);
                listBox1.Items.Add("Street Name: " + "\t" + StreetName);
                listBox1.Items.Add("Surburb: " + "\t" + Surburb);
                listBox1.Items.Add("Province: " + "\t" + Province);
                listBox1.Items.Add("Postal Code: " + "\t" + PostalCode);
                listBox1.Items.Add("Email Address:" + "\t" + emailAdress);
                listBox1.Items.Add("Cellphone Number: " + "\t" + CellNumber);

                if (txtConfirmPassword.Text != txtPassword.Text)
                {
                    MessageBox.Show("The passwords do not match!");
                    txtPassword.Text = " ";
                    txtConfirmPassword.Text = " ";
                }
                else if (txtPassword.TextLength < 8)
                {
                    MessageBox.Show("Password is less than 8 characters");
                }
                else
                {
                    BtnConfirm.Visible = true;
                    BtnRegister.Visible = false;
                }

            }
            catch (Exception ex)
            { 
                //if theres an error in the code we will know what the error is because it will be shown in a message box
                MessageBox.Show(ex.Message);
            }
            

        }

        
        

        
       

        

        private void RegisterPage_Load(object sender, EventArgs e)
        {
            BtnConfirm.Visible = false;

            //sesotho language 
            if(chosenLanguage == "sesotho")
            {
                lblheading.Text = "IVC LEPHEPHE LA NGODISO";

                groupBox1.Text = "disntla tse di amanang le uena";
                lbltitle.Text = "Sehlooho:";
                lblGender.Text = "Bong";
                lblFirstName.Text = "Lebitso la Pele: ";
                lblLastName.Text = "fane";
                lblMiddleName.Text = "Lebitso la Gare:";

                gbContactInfromation.Text = "Aterese ea Sebaka";
                lblStreetname.Text = "Nomoro ea Ntlo:";
                lblStreetname.Text = "Lebisto la seterata:";
                lblSurburb.Text = "Toropo:";
                lblProvicnce.Text = "Profinse:";
                lblPostalcode.Text = "Nomora ea Poso:";

                gbContactInfromation.Text = "Dintlha tsa mohala";
                lblemail.Text = "Aterese ea Imeile:";
                lblCellphone.Text = "Nomoro ea Mohala(+27):";

                GbPhysicalAdress.Text = "Dintlha tsa ho kena";
                lblIDNumber.Text = "Nomoro ea ID:";
                LblPassword.Text = "Phasewete";
                lblConfirmPassword.Text = "Netefatsa Phasewete";

                BtnBack.Text = "morao";
                BtnRegister.Text = "ngodisa";
            }
            else if(chosenLanguage == "afrikaans")
            {
                lblheading.Text = "IVC REGISTEREER BLADSY";

                groupBox1.Text = "Personlik inligting";
                lbltitle.Text = "Titel:";
                lblGender.Text = "Geslag";
                lblFirstName.Text = "Eerste Naam: ";
                lblLastName.Text = "Laaste Naam";
                lblMiddleName.Text = "Middel Naam:";

                gbContactInfromation.Text = "Kontak Inligting";
                lblStreetname.Text = "Straat Nommer:";
                lblStreetname.Text = "Straat Naam:";
                lblSurburb.Text = "Dorp:";
                lblProvicnce.Text = "Profinsie:";
                lblPostalcode.Text = "Poskode:";

                gbContactInfromation.Text = "Kontak Inligting";
                lblemail.Text = "E-Pos Adres:";
                lblCellphone.Text = "Selfoon Nommer(+27):";

                GbPhysicalAdress.Text = "Teken AanInligting";
                lblIDNumber.Text = "ID Nommer:";
                LblPassword.Text = "Wagwoord:";
                lblConfirmPassword.Text = "Bevestig wagwoord";

                BtnBack.Text = "Terug";
                BtnRegister.Text = "Registereer";
            }
            else{
                //change this to english for the default lanuage to be english 
                lblheading.Text = "IVC REGISTERATION PAGE";

                groupBox1.Text = "Physical Adress";
                lbltitle.Text = "Title:";
                lblGender.Text = "Gender:";
                lblFirstName.Text = "First Name: ";
                lblLastName.Text = "Last Name: ";
                lblMiddleName.Text = "Middle Name:";

                GbPhysicalAdress.Text = "Physical Adress";
                lblStreetname.Text = "Street Name: ";
                lblSurburb.Text = "Surburb/Town: ";
                lblProvicnce.Text = "Province:";
                lblPostalcode.Text = "Postal code:";

                gbContactInfromation.Text = "Ulwazi lokuxhumana";
                lblemail.Text = "I-imeyili:";
                lblCellphone.Text = "Inombolo yeselula(+27):";

                GbPhysicalAdress.Text = "Ikheli lendawo";
                lblIDNumber.Text = "Inombolo ye-ID:";
                LblPassword.Text = "Iphasiwedi:";
                lblConfirmPassword.Text = "Qinisekisa iphasiwedi";

                BtnBack.Text = "Emuva";
                BtnRegister.Text = "Bhalisa";
            }

            try
            {
                connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30");
                connection.Open();
                connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
