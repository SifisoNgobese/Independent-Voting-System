﻿using Group23Project_IndependentVotingCommision.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Group23Project_IndependentVotingCommision
{
    public partial class frmWelcomePage : Form
    {
        //String language set here to allow variable language to be used in other forms
        public frmWelcomePage()
        {
            InitializeComponent();
        }


        public string Language { get;set; }

        private void frmWelcomePage_Load(object sender, EventArgs e)
        {
           

            listBox1.Items.Add("1. You are only eligible to vote only if you are 18 and older\n\n");
            listBox1.Items.Add("2. You can only the system ONCE after you have logged in\n\n");
            listBox1.Items.Add("3. You can only choose ONE party in the ballot sheet\n\n");
            listBox1.Items.Add("4. Personal information provided to the voting commision will be stored on our local databases\n\n");
            listBox1.Items.Add("5. The ICV will not be held liable should any information be leaked to in the event of a cyber security threat");            
        }

       

        private void btnRegister2_Click(object sender, EventArgs e)
        {
            RegisterPage RP = new RegisterPage(Language);
            RP.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            LoginPage loginPage = new LoginPage(Language);
            loginPage.Show();
            this.Hide();
        }

        private void cbTermsAndConditions_CheckedChanged(object sender, EventArgs e)
        {
            if(cbTermsAndConditions.Checked)
            {
                btnLogin.Enabled = true;
                btnRegister2.Enabled = true;

            }
        }

        
        private void radioEnglish_CheckedChanged(object sender, EventArgs e)
        {
            Language = "english";


            lblLanguageChosen.Show();
            lblLanguageChosen.Text = "english language chosen";
            btnLogin.Text = "login";
            btnRegister2.Text = "Register";
            lblWelcomePageText.Text = "Welcome Page";
            cbTermsAndConditions.Text = "i agree to accept the terms and conditions before proceeding";


            listBox1.Items.Clear();
            listBox1.Items.Add("1. You are only eligible to vote only if you are 18 and older\n\n");
            listBox1.Items.Add("2. You can only the system ONCE after you have logged in\n\n");
            listBox1.Items.Add("3. You can only choose ONE party in the ballot sheet\n\n");
            listBox1.Items.Add("4. Personal information provided to the voting commision will be stored on our local databases\n\n");
            listBox1.Items.Add("5. The ICV will not be held liable should any information be leaked to in the event of a cyber security threat");
        }

        private void radioSesotho_CheckedChanged(object sender, EventArgs e)
        {
            //allows the string sesotho to be stored in language 
            Language = "sesotho";


            //change language 
            lblLanguageChosen.Show();
            lblLanguageChosen.Text = "O kgethile konopo e fetolelang Sesotho";
            btnLogin.Text = "Kena";
            btnRegister2.Text = "Nogdisa";
            lblWelcomePageText.Text = "Leqephe la kamohelo";
            cbTermsAndConditions.Text = "ke lumela ho amohela lipehelo le lipehelo pele ke tsoela pele";


            listBox1.Items.Clear(); ;
            listBox1.Items.Add("1. O tshwaneleha ho vouta ha feela o le dilemo di 18 ho ya hodimo\n\n");
            listBox1.Items.Add("2. U ka khona feela tsamaiso hang ka mor'a hore u kene\n\n");
            listBox1.Items.Add("3. O ka khetha feela mokga o LE LENG leqepheng la ho vouta\n\n");
            listBox1.Items.Add("4. Lintlha tsa botho tse fanoeng ho khomishene ea likhetho li tla bolokoa ho database tsa rona tsa lehae\n\n");
            listBox1.Items.Add("5. ICV e ke ke ea jara boikarabello haeba tlhahisoleseling efe kapa efe e ka hlahisoa ha ho ka ba le ts'okelo ea ts'ireletso ea marang-rang.");
        }

        private void radioAfrikaans_CheckedChanged(object sender, EventArgs e)
        {
            Language = "afrikaans";

            lblLanguageChosen.Show();
            lblLanguageChosen.Text = "Jy het gekies om na Afrikaans te vertaal";
            btnLogin.Text = "Teken Aan";
            btnRegister2.Text = "Registereer";
            lblWelcomePageText.Text = "Welkom Bladsy";
            cbTermsAndConditions.Text = "ek stem in om die bepalings en voorwaardes te aanvaar voordat ek voortgaan";


            listBox1.Items.Clear();
            listBox1.Items.Add("1. Jy is slegs stemgeregtig as jy 18 en ouer is");
            listBox1.Items.Add("2. Jy kan eers die stelsel bestuur sodra jy ingeteken het");
            listBox1.Items.Add("3. Jy kan net vir EEN party op die stembrief stem");
            listBox1.Items.Add("4. Persoonlike data wat aan die verkiesingskommissie verskaf word, sal in ons plaaslike databasisse gestoor word");
            listBox1.Items.Add("5. ICV sal nie verantwoordelik gehou word indien enige inligting bekend gemaak word in die geval van 'n kubersekuriteitsbedreiging nie.");
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void radioZulu_CheckedChanged(object sender, EventArgs e)
        {
            Language = "isiZulu";

            lblLanguageChosen.Show();
            lblLanguageChosen.Text = "Ukhethe ukuhumushela kwisiBhunu";
            btnLogin.Text = "Ngena ngemvume";
            btnRegister2.Text = "Bhalisa";
            lblWelcomePageText.Text = "Ikhasi Lokwamukela";
            cbTermsAndConditions.Text = "Ngiyavuma ukwamukela imigomo nemibandela ngaphambi kokuqhubeka";


            listBox1.Items.Clear();
            listBox1.Items.Add("1. Ufaneleka ukuvota kuphela uma uneminyaka eyi-18 nangaphezulu");
            listBox1.Items.Add("2. Ungakwazi ukuphatha uhlelo kuphela uma usungenile");
            listBox1.Items.Add("3. Ungavotela iqembu ELILODWA kuphela ephepheni lokuvota");
            listBox1.Items.Add("4. Idatha yomuntu siqu enikezwe ikhomishana yokhetho izogcinwa kusizindalwazi sethu sendawo");
            listBox1.Items.Add("5. I-ICV ngeke ithweswe icala uma kukhona ulwazi oludalulwayo uma kwenzeka kuba nosongo lokuphepha ku-inthanethi.");
        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {   

            // takes you to admin login page
            frmAdminLogin myform = new frmAdminLogin();
            myform.Show();
            this.Hide();
        }
    }
    
}
