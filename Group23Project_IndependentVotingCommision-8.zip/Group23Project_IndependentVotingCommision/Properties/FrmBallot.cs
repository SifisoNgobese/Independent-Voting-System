﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class FrmBallot : Form
    {
        public string sqlcommand;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();

        public string sqlcommand2;
        SqlCommand command2 = new SqlCommand();
        SqlDataAdapter adapter2 = new SqlDataAdapter();

        public string vote;
        int BallotID;

        string ID_BallotForm2;
        public FrmBallot(string ID_BallotForm)
        {
            InitializeComponent();
            ID_BallotForm2 = ID_BallotForm;
        }

        

        private void btnLogOut_Click_1(object sender, EventArgs e)
        {
            LoginPage login = new LoginPage();
            login.Show();
            this.Hide();
        }

        private void FrmBallot_Load(object sender, EventArgs e)
        {
            MessageBox.Show(ID_BallotForm2.ToString());
            try
            {
                connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\27685\OneDrive\Documents\IVC_Database.mdf;Integrated Security=True;Connect Timeout=30");
                connection.Open();
                connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnConfirmVote_Click(object sender, EventArgs e)
        {
            
            if (radioABDP.Checked)
            {
                vote = "ABDP";
            }
            else if (radioANC.Checked)
            {
                vote = "ANC";
            }
            else if (radioDA.Checked)
            {
                vote = "DA";
            }
            else if (radioEFF.Checked)
            {
                vote = "EFF";
            }
            else if (radioIFP.Checked)
            {
                vote = "IFP";
            }
            else if (radioUDM.Checked)
            {
                vote = "UDM";
            }
            else
            {
                MessageBox.Show("Please choose a political party");
            }
            try
            {
                Random random = new Random();
                int randomNumber = random.Next(1, 999999999);
                
                connection.Open();
                sqlcommand2 = $"INSERT INTO VotesRecorded (VoterID, BallotID) VALUES ('{ID_BallotForm2}', {randomNumber})";
                command2 = new SqlCommand(sqlcommand2, connection);
                adapter2.InsertCommand = command2;
                adapter2.InsertCommand.ExecuteNonQuery();
                connection.Close();


                connection.Open();
                sqlcommand = $"UPDATE VotesRecorded SET PartyVoted = '{vote}' WHERE VoterID = {ID_BallotForm2}";
                command = new SqlCommand(sqlcommand, connection);
                adapter.InsertCommand = command;
                adapter.InsertCommand.ExecuteNonQuery();

                MessageBox.Show("Your Vote has been recorded sucessfully");

                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Hide();
                connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
