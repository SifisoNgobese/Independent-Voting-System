﻿namespace Group23Project_IndependentVotingCommision.Properties
{
    partial class RegisterPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblheading = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblCellphone = new System.Windows.Forms.Label();
            this.txtCellPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblStreetname = new System.Windows.Forms.Label();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbTitle = new System.Windows.Forms.ComboBox();
            this.CbGender = new System.Windows.Forms.ComboBox();
            this.gbContactInfromation = new System.Windows.Forms.GroupBox();
            this.lblEmailerror = new System.Windows.Forms.Label();
            this.lblNumbererror = new System.Windows.Forms.Label();
            this.GbPhysicalAdress = new System.Windows.Forms.GroupBox();
            this.cbProvince = new System.Windows.Forms.ComboBox();
            this.lblPostalcode = new System.Windows.Forms.Label();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.lblSurburb = new System.Windows.Forms.Label();
            this.txtSurburb = new System.Windows.Forms.TextBox();
            this.lblProvicnce = new System.Windows.Forms.Label();
            this.lblhousenumber = new System.Windows.Forms.Label();
            this.txtHouseNumber = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.BtnRegister = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            this.gbLoginInfromation = new System.Windows.Forms.GroupBox();
            this.lblConfrimPassworderror = new System.Windows.Forms.Label();
            this.lblPasswordError = new System.Windows.Forms.Label();
            this.lblIDNumbererror = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.lblIDNumber = new System.Windows.Forms.Label();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.LblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.BtnConfirm = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbContactInfromation.SuspendLayout();
            this.GbPhysicalAdress.SuspendLayout();
            this.gbLoginInfromation.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblheading);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1446, 110);
            this.panel1.TabIndex = 0;
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(344, 20);
            this.lblheading.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(898, 73);
            this.lblheading.TabIndex = 3;
            this.lblheading.Text = "IVC REGISTERATION PAGE";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Location = new System.Drawing.Point(16, 51);
            this.lbltitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(30, 13);
            this.lbltitle.TabIndex = 4;
            this.lbltitle.Text = "Title:";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(16, 98);
            this.lblGender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(45, 13);
            this.lblGender.TabIndex = 5;
            this.lblGender.Text = "Gender:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(16, 150);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 6;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.Location = new System.Drawing.Point(16, 229);
            this.lblMiddleName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(72, 13);
            this.lblMiddleName.TabIndex = 7;
            this.lblMiddleName.Text = "Middle Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(398, 145);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(2);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(148, 20);
            this.txtFirstName.TabIndex = 10;
            this.txtFirstName.TextChanged += new System.EventHandler(this.txtFirstName_TextChanged);
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(398, 224);
            this.txtMiddleName.Margin = new System.Windows.Forms.Padding(2);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(148, 20);
            this.txtMiddleName.TabIndex = 11;
            this.txtMiddleName.TextChanged += new System.EventHandler(this.txtMiddleName_TextChanged);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(16, 293);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 12;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(398, 288);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(2);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(148, 20);
            this.txtLastName.TabIndex = 13;
            this.txtLastName.TextChanged += new System.EventHandler(this.txtLastName_TextChanged);
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(4, 51);
            this.lblemail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(76, 13);
            this.lblemail.TabIndex = 14;
            this.lblemail.Text = "Email Address:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(386, 46);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(148, 20);
            this.txtEmail.TabIndex = 15;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // lblCellphone
            // 
            this.lblCellphone.AutoSize = true;
            this.lblCellphone.Location = new System.Drawing.Point(4, 124);
            this.lblCellphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCellphone.Name = "lblCellphone";
            this.lblCellphone.Size = new System.Drawing.Size(121, 13);
            this.lblCellphone.TabIndex = 16;
            this.lblCellphone.Text = "Cellphone Number(+27):";
            // 
            // txtCellPhoneNumber
            // 
            this.txtCellPhoneNumber.Location = new System.Drawing.Point(386, 124);
            this.txtCellPhoneNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtCellPhoneNumber.Name = "txtCellPhoneNumber";
            this.txtCellPhoneNumber.Size = new System.Drawing.Size(148, 20);
            this.txtCellPhoneNumber.TabIndex = 17;
            this.txtCellPhoneNumber.TextChanged += new System.EventHandler(this.txtCellPhoneNumber_TextChanged);
            // 
            // lblStreetname
            // 
            this.lblStreetname.AutoSize = true;
            this.lblStreetname.Location = new System.Drawing.Point(16, 73);
            this.lblStreetname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStreetname.Name = "lblStreetname";
            this.lblStreetname.Size = new System.Drawing.Size(66, 13);
            this.lblStreetname.TabIndex = 18;
            this.lblStreetname.Text = "Street Name";
            // 
            // txtStreetName
            // 
            this.txtStreetName.Location = new System.Drawing.Point(398, 73);
            this.txtStreetName.Margin = new System.Windows.Forms.Padding(2);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(148, 20);
            this.txtStreetName.TabIndex = 19;
            this.txtStreetName.TextChanged += new System.EventHandler(this.txtStreetName_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbTitle);
            this.groupBox1.Controls.Add(this.CbGender);
            this.groupBox1.Controls.Add(this.lbltitle);
            this.groupBox1.Controls.Add(this.lblFirstName);
            this.groupBox1.Controls.Add(this.lblGender);
            this.groupBox1.Controls.Add(this.lblMiddleName);
            this.groupBox1.Controls.Add(this.txtFirstName);
            this.groupBox1.Controls.Add(this.txtLastName);
            this.groupBox1.Controls.Add(this.txtMiddleName);
            this.groupBox1.Controls.Add(this.lblLastName);
            this.groupBox1.Location = new System.Drawing.Point(106, 124);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(656, 344);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Infromation";
            // 
            // cbTitle
            // 
            this.cbTitle.FormattingEnabled = true;
            this.cbTitle.Items.AddRange(new object[] {
            "Mr",
            "Mrs",
            "Miss",
            "Dr.",
            "Adv.",
            "Prof."});
            this.cbTitle.Location = new System.Drawing.Point(398, 49);
            this.cbTitle.Margin = new System.Windows.Forms.Padding(2);
            this.cbTitle.Name = "cbTitle";
            this.cbTitle.Size = new System.Drawing.Size(148, 21);
            this.cbTitle.TabIndex = 30;
            // 
            // CbGender
            // 
            this.CbGender.FormattingEnabled = true;
            this.CbGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other "});
            this.CbGender.Location = new System.Drawing.Point(398, 96);
            this.CbGender.Margin = new System.Windows.Forms.Padding(2);
            this.CbGender.Name = "CbGender";
            this.CbGender.Size = new System.Drawing.Size(148, 21);
            this.CbGender.TabIndex = 29;
            // 
            // gbContactInfromation
            // 
            this.gbContactInfromation.Controls.Add(this.lblEmailerror);
            this.gbContactInfromation.Controls.Add(this.lblNumbererror);
            this.gbContactInfromation.Controls.Add(this.lblemail);
            this.gbContactInfromation.Controls.Add(this.txtEmail);
            this.gbContactInfromation.Controls.Add(this.lblCellphone);
            this.gbContactInfromation.Controls.Add(this.txtCellPhoneNumber);
            this.gbContactInfromation.Location = new System.Drawing.Point(790, 124);
            this.gbContactInfromation.Margin = new System.Windows.Forms.Padding(2);
            this.gbContactInfromation.Name = "gbContactInfromation";
            this.gbContactInfromation.Padding = new System.Windows.Forms.Padding(2);
            this.gbContactInfromation.Size = new System.Drawing.Size(548, 176);
            this.gbContactInfromation.TabIndex = 21;
            this.gbContactInfromation.TabStop = false;
            this.gbContactInfromation.Text = "Contact Infromation";
            // 
            // lblEmailerror
            // 
            this.lblEmailerror.AutoSize = true;
            this.lblEmailerror.ForeColor = System.Drawing.Color.Red;
            this.lblEmailerror.Location = new System.Drawing.Point(4, 64);
            this.lblEmailerror.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmailerror.Name = "lblEmailerror";
            this.lblEmailerror.Size = new System.Drawing.Size(28, 13);
            this.lblEmailerror.TabIndex = 24;
            this.lblEmailerror.Text = "error";
            this.lblEmailerror.Visible = false;
            // 
            // lblNumbererror
            // 
            this.lblNumbererror.AutoSize = true;
            this.lblNumbererror.ForeColor = System.Drawing.Color.Red;
            this.lblNumbererror.Location = new System.Drawing.Point(4, 137);
            this.lblNumbererror.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumbererror.Name = "lblNumbererror";
            this.lblNumbererror.Size = new System.Drawing.Size(28, 13);
            this.lblNumbererror.TabIndex = 20;
            this.lblNumbererror.Text = "error";
            this.lblNumbererror.Visible = false;
            // 
            // GbPhysicalAdress
            // 
            this.GbPhysicalAdress.Controls.Add(this.cbProvince);
            this.GbPhysicalAdress.Controls.Add(this.lblPostalcode);
            this.GbPhysicalAdress.Controls.Add(this.txtPostalCode);
            this.GbPhysicalAdress.Controls.Add(this.lblSurburb);
            this.GbPhysicalAdress.Controls.Add(this.txtSurburb);
            this.GbPhysicalAdress.Controls.Add(this.lblProvicnce);
            this.GbPhysicalAdress.Controls.Add(this.lblhousenumber);
            this.GbPhysicalAdress.Controls.Add(this.txtHouseNumber);
            this.GbPhysicalAdress.Controls.Add(this.lblStreetname);
            this.GbPhysicalAdress.Controls.Add(this.txtStreetName);
            this.GbPhysicalAdress.Location = new System.Drawing.Point(106, 473);
            this.GbPhysicalAdress.Margin = new System.Windows.Forms.Padding(2);
            this.GbPhysicalAdress.Name = "GbPhysicalAdress";
            this.GbPhysicalAdress.Padding = new System.Windows.Forms.Padding(2);
            this.GbPhysicalAdress.Size = new System.Drawing.Size(656, 250);
            this.GbPhysicalAdress.TabIndex = 22;
            this.GbPhysicalAdress.TabStop = false;
            this.GbPhysicalAdress.Text = "Physical Adress";
            // 
            // cbProvince
            // 
            this.cbProvince.FormattingEnabled = true;
            this.cbProvince.Items.AddRange(new object[] {
            "Gauteng",
            "Free State",
            "Western Cape",
            "Northern Cape",
            "Eastern Cape",
            "Kwa-Zulu Natal",
            "Mpumalanga",
            "Limpopo",
            "North West"});
            this.cbProvince.Location = new System.Drawing.Point(398, 167);
            this.cbProvince.Margin = new System.Windows.Forms.Padding(2);
            this.cbProvince.Name = "cbProvince";
            this.cbProvince.Size = new System.Drawing.Size(148, 21);
            this.cbProvince.TabIndex = 28;
            // 
            // lblPostalcode
            // 
            this.lblPostalcode.AutoSize = true;
            this.lblPostalcode.Location = new System.Drawing.Point(15, 205);
            this.lblPostalcode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPostalcode.Name = "lblPostalcode";
            this.lblPostalcode.Size = new System.Drawing.Size(63, 13);
            this.lblPostalcode.TabIndex = 26;
            this.lblPostalcode.Text = "Postal code";
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(398, 205);
            this.txtPostalCode.Margin = new System.Windows.Forms.Padding(2);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(148, 20);
            this.txtPostalCode.TabIndex = 27;
            this.txtPostalCode.TextChanged += new System.EventHandler(this.txtPostalCode_TextChanged);
            // 
            // lblSurburb
            // 
            this.lblSurburb.AutoSize = true;
            this.lblSurburb.Location = new System.Drawing.Point(16, 117);
            this.lblSurburb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSurburb.Name = "lblSurburb";
            this.lblSurburb.Size = new System.Drawing.Size(76, 13);
            this.lblSurburb.TabIndex = 24;
            this.lblSurburb.Text = "Surburb/Town";
            // 
            // txtSurburb
            // 
            this.txtSurburb.Location = new System.Drawing.Point(398, 117);
            this.txtSurburb.Margin = new System.Windows.Forms.Padding(2);
            this.txtSurburb.Name = "txtSurburb";
            this.txtSurburb.Size = new System.Drawing.Size(148, 20);
            this.txtSurburb.TabIndex = 25;
            this.txtSurburb.TextChanged += new System.EventHandler(this.txtSurburb_TextChanged);
            // 
            // lblProvicnce
            // 
            this.lblProvicnce.AutoSize = true;
            this.lblProvicnce.Location = new System.Drawing.Point(16, 167);
            this.lblProvicnce.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProvicnce.Name = "lblProvicnce";
            this.lblProvicnce.Size = new System.Drawing.Size(49, 13);
            this.lblProvicnce.TabIndex = 22;
            this.lblProvicnce.Text = "Province";
            // 
            // lblhousenumber
            // 
            this.lblhousenumber.AutoSize = true;
            this.lblhousenumber.Location = new System.Drawing.Point(16, 26);
            this.lblhousenumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblhousenumber.Name = "lblhousenumber";
            this.lblhousenumber.Size = new System.Drawing.Size(74, 13);
            this.lblhousenumber.TabIndex = 20;
            this.lblhousenumber.Text = "house number";
            this.lblhousenumber.Click += new System.EventHandler(this.lblhousenumber_Click);
            // 
            // txtHouseNumber
            // 
            this.txtHouseNumber.Location = new System.Drawing.Point(398, 24);
            this.txtHouseNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtHouseNumber.Name = "txtHouseNumber";
            this.txtHouseNumber.Size = new System.Drawing.Size(148, 20);
            this.txtHouseNumber.TabIndex = 21;
            this.txtHouseNumber.TextChanged += new System.EventHandler(this.txtHouseNumber_TextChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(790, 482);
            this.listBox1.Margin = new System.Windows.Forms.Padding(2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(548, 251);
            this.listBox1.TabIndex = 23;
            // 
            // BtnRegister
            // 
            this.BtnRegister.Location = new System.Drawing.Point(1165, 750);
            this.BtnRegister.Margin = new System.Windows.Forms.Padding(2);
            this.BtnRegister.Name = "BtnRegister";
            this.BtnRegister.Size = new System.Drawing.Size(173, 50);
            this.BtnRegister.TabIndex = 24;
            this.BtnRegister.Text = "Register";
            this.BtnRegister.UseVisualStyleBackColor = true;
            this.BtnRegister.Click += new System.EventHandler(this.BtnRegister_Click);
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(976, 750);
            this.BtnBack.Margin = new System.Windows.Forms.Padding(2);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(173, 50);
            this.BtnBack.TabIndex = 25;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // gbLoginInfromation
            // 
            this.gbLoginInfromation.Controls.Add(this.lblConfrimPassworderror);
            this.gbLoginInfromation.Controls.Add(this.lblPasswordError);
            this.gbLoginInfromation.Controls.Add(this.lblIDNumbererror);
            this.gbLoginInfromation.Controls.Add(this.lblConfirmPassword);
            this.gbLoginInfromation.Controls.Add(this.txtConfirmPassword);
            this.gbLoginInfromation.Controls.Add(this.lblIDNumber);
            this.gbLoginInfromation.Controls.Add(this.txtIDNumber);
            this.gbLoginInfromation.Controls.Add(this.LblPassword);
            this.gbLoginInfromation.Controls.Add(this.txtPassword);
            this.gbLoginInfromation.Location = new System.Drawing.Point(790, 306);
            this.gbLoginInfromation.Margin = new System.Windows.Forms.Padding(2);
            this.gbLoginInfromation.Name = "gbLoginInfromation";
            this.gbLoginInfromation.Padding = new System.Windows.Forms.Padding(2);
            this.gbLoginInfromation.Size = new System.Drawing.Size(548, 162);
            this.gbLoginInfromation.TabIndex = 22;
            this.gbLoginInfromation.TabStop = false;
            this.gbLoginInfromation.Text = "Login Infromation";
            // 
            // lblConfrimPassworderror
            // 
            this.lblConfrimPassworderror.AutoSize = true;
            this.lblConfrimPassworderror.ForeColor = System.Drawing.Color.Red;
            this.lblConfrimPassworderror.Location = new System.Drawing.Point(4, 126);
            this.lblConfrimPassworderror.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblConfrimPassworderror.Name = "lblConfrimPassworderror";
            this.lblConfrimPassworderror.Size = new System.Drawing.Size(28, 13);
            this.lblConfrimPassworderror.TabIndex = 23;
            this.lblConfrimPassworderror.Text = "error";
            this.lblConfrimPassworderror.Visible = false;
            // 
            // lblPasswordError
            // 
            this.lblPasswordError.AutoSize = true;
            this.lblPasswordError.ForeColor = System.Drawing.Color.Red;
            this.lblPasswordError.Location = new System.Drawing.Point(4, 89);
            this.lblPasswordError.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPasswordError.Name = "lblPasswordError";
            this.lblPasswordError.Size = new System.Drawing.Size(28, 13);
            this.lblPasswordError.TabIndex = 22;
            this.lblPasswordError.Text = "error";
            this.lblPasswordError.Visible = false;
            // 
            // lblIDNumbererror
            // 
            this.lblIDNumbererror.AutoSize = true;
            this.lblIDNumbererror.ForeColor = System.Drawing.Color.Red;
            this.lblIDNumbererror.Location = new System.Drawing.Point(4, 53);
            this.lblIDNumbererror.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIDNumbererror.Name = "lblIDNumbererror";
            this.lblIDNumbererror.Size = new System.Drawing.Size(28, 13);
            this.lblIDNumbererror.TabIndex = 21;
            this.lblIDNumbererror.Text = "error";
            this.lblIDNumbererror.Visible = false;
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new System.Drawing.Point(4, 113);
            this.lblConfirmPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(94, 13);
            this.lblConfirmPassword.TabIndex = 18;
            this.lblConfirmPassword.Text = "Confirm Password:";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(386, 108);
            this.txtConfirmPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(148, 20);
            this.txtConfirmPassword.TabIndex = 19;
            // 
            // lblIDNumber
            // 
            this.lblIDNumber.AutoSize = true;
            this.lblIDNumber.Location = new System.Drawing.Point(4, 40);
            this.lblIDNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIDNumber.Name = "lblIDNumber";
            this.lblIDNumber.Size = new System.Drawing.Size(61, 13);
            this.lblIDNumber.TabIndex = 14;
            this.lblIDNumber.Text = "ID Number:";
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.Location = new System.Drawing.Point(386, 35);
            this.txtIDNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(148, 20);
            this.txtIDNumber.TabIndex = 15;
            this.txtIDNumber.TextChanged += new System.EventHandler(this.txtIDNumber_TextChanged);
            // 
            // LblPassword
            // 
            this.LblPassword.AutoSize = true;
            this.LblPassword.Location = new System.Drawing.Point(4, 76);
            this.LblPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPassword.Name = "LblPassword";
            this.LblPassword.Size = new System.Drawing.Size(56, 13);
            this.LblPassword.TabIndex = 16;
            this.LblPassword.Text = "Password:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(386, 72);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(148, 20);
            this.txtPassword.TabIndex = 17;
            // 
            // BtnConfirm
            // 
            this.BtnConfirm.Location = new System.Drawing.Point(1218, 725);
            this.BtnConfirm.Margin = new System.Windows.Forms.Padding(2);
            this.BtnConfirm.Name = "BtnConfirm";
            this.BtnConfirm.Size = new System.Drawing.Size(173, 50);
            this.BtnConfirm.TabIndex = 26;
            this.BtnConfirm.Text = "Confirm";
            this.BtnConfirm.UseVisualStyleBackColor = true;
            this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
            // 
            // RegisterPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1402, 770);
            this.Controls.Add(this.BtnConfirm);
            this.Controls.Add(this.gbLoginInfromation);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.BtnRegister);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.GbPhysicalAdress);
            this.Controls.Add(this.gbContactInfromation);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RegisterPage";
            this.Text = "RegisterPage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.RegisterPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbContactInfromation.ResumeLayout(false);
            this.gbContactInfromation.PerformLayout();
            this.GbPhysicalAdress.ResumeLayout(false);
            this.GbPhysicalAdress.PerformLayout();
            this.gbLoginInfromation.ResumeLayout(false);
            this.gbLoginInfromation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblCellphone;
        private System.Windows.Forms.TextBox txtCellPhoneNumber;
        private System.Windows.Forms.Label lblStreetname;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox gbContactInfromation;
        private System.Windows.Forms.GroupBox GbPhysicalAdress;
        private System.Windows.Forms.Label lblhousenumber;
        private System.Windows.Forms.TextBox txtHouseNumber;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button BtnRegister;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Label lblSurburb;
        private System.Windows.Forms.TextBox txtSurburb;
        private System.Windows.Forms.Label lblProvicnce;
        private System.Windows.Forms.ComboBox cbProvince;
        private System.Windows.Forms.Label lblPostalcode;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.ComboBox cbTitle;
        private System.Windows.Forms.ComboBox CbGender;
        private System.Windows.Forms.GroupBox gbLoginInfromation;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label lblIDNumber;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.Label LblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button BtnConfirm;
        private System.Windows.Forms.Label lblNumbererror;
        private System.Windows.Forms.Label lblEmailerror;
        private System.Windows.Forms.Label lblConfrimPassworderror;
        private System.Windows.Forms.Label lblPasswordError;
        private System.Windows.Forms.Label lblIDNumbererror;
    }
}