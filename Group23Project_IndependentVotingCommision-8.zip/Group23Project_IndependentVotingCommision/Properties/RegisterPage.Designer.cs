﻿namespace Group23Project_IndependentVotingCommision.Properties
{
    partial class RegisterPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblheading = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblCellphone = new System.Windows.Forms.Label();
            this.txtCellPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblStreetname = new System.Windows.Forms.Label();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbTitle = new System.Windows.Forms.ComboBox();
            this.CbGender = new System.Windows.Forms.ComboBox();
            this.gbContactInfromation = new System.Windows.Forms.GroupBox();
            this.lblerror = new System.Windows.Forms.Label();
            this.GbPhysicalAdress = new System.Windows.Forms.GroupBox();
            this.cbProvince = new System.Windows.Forms.ComboBox();
            this.lblPostalcode = new System.Windows.Forms.Label();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.lblSurburb = new System.Windows.Forms.Label();
            this.txtSurburb = new System.Windows.Forms.TextBox();
            this.lblProvicnce = new System.Windows.Forms.Label();
            this.lblhousenumber = new System.Windows.Forms.Label();
            this.txtHouseNumber = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.BtnRegister = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            this.gbLoginInfromation = new System.Windows.Forms.GroupBox();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.lblIDNumber = new System.Windows.Forms.Label();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.LblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.BtnConfirm = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbContactInfromation.SuspendLayout();
            this.GbPhysicalAdress.SuspendLayout();
            this.gbLoginInfromation.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblheading);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1928, 136);
            this.panel1.TabIndex = 0;
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(459, 25);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(1109, 91);
            this.lblheading.TabIndex = 3;
            this.lblheading.Text = "IVC REGISTERATION PAGE";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Location = new System.Drawing.Point(22, 63);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(36, 16);
            this.lbltitle.TabIndex = 4;
            this.lbltitle.Text = "Title:";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(22, 121);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(55, 16);
            this.lblGender.TabIndex = 5;
            this.lblGender.Text = "Gender:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(22, 185);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(75, 16);
            this.lblFirstName.TabIndex = 6;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.Location = new System.Drawing.Point(22, 282);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(91, 16);
            this.lblMiddleName.TabIndex = 7;
            this.lblMiddleName.Text = "Middle Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(530, 179);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(196, 22);
            this.txtFirstName.TabIndex = 10;
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(530, 276);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(196, 22);
            this.txtMiddleName.TabIndex = 11;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(22, 361);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(75, 16);
            this.lblLastName.TabIndex = 12;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(530, 355);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(196, 22);
            this.txtLastName.TabIndex = 13;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(6, 63);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(98, 16);
            this.lblemail.TabIndex = 14;
            this.lblemail.Text = "Email Address:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(514, 57);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(196, 22);
            this.txtEmail.TabIndex = 15;
            // 
            // lblCellphone
            // 
            this.lblCellphone.AutoSize = true;
            this.lblCellphone.Location = new System.Drawing.Point(6, 153);
            this.lblCellphone.Name = "lblCellphone";
            this.lblCellphone.Size = new System.Drawing.Size(151, 16);
            this.lblCellphone.TabIndex = 16;
            this.lblCellphone.Text = "Cellphone Number(+27):";
            // 
            // txtCellPhoneNumber
            // 
            this.txtCellPhoneNumber.Location = new System.Drawing.Point(514, 153);
            this.txtCellPhoneNumber.Name = "txtCellPhoneNumber";
            this.txtCellPhoneNumber.Size = new System.Drawing.Size(196, 22);
            this.txtCellPhoneNumber.TabIndex = 17;
            this.txtCellPhoneNumber.TextChanged += new System.EventHandler(this.txtCellPhoneNumber_TextChanged);
            // 
            // lblStreetname
            // 
            this.lblStreetname.AutoSize = true;
            this.lblStreetname.Location = new System.Drawing.Point(21, 90);
            this.lblStreetname.Name = "lblStreetname";
            this.lblStreetname.Size = new System.Drawing.Size(82, 16);
            this.lblStreetname.TabIndex = 18;
            this.lblStreetname.Text = "Street Name";
            // 
            // txtStreetName
            // 
            this.txtStreetName.Location = new System.Drawing.Point(531, 90);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(196, 22);
            this.txtStreetName.TabIndex = 19;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbTitle);
            this.groupBox1.Controls.Add(this.CbGender);
            this.groupBox1.Controls.Add(this.lbltitle);
            this.groupBox1.Controls.Add(this.lblFirstName);
            this.groupBox1.Controls.Add(this.lblGender);
            this.groupBox1.Controls.Add(this.lblMiddleName);
            this.groupBox1.Controls.Add(this.txtFirstName);
            this.groupBox1.Controls.Add(this.txtLastName);
            this.groupBox1.Controls.Add(this.txtMiddleName);
            this.groupBox1.Controls.Add(this.lblLastName);
            this.groupBox1.Location = new System.Drawing.Point(142, 152);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(875, 424);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Infromation";
            // 
            // cbTitle
            // 
            this.cbTitle.FormattingEnabled = true;
            this.cbTitle.Items.AddRange(new object[] {
            "Mr",
            "Mrs",
            "Miss",
            "Dr.",
            "Adv.",
            "Prof."});
            this.cbTitle.Location = new System.Drawing.Point(531, 60);
            this.cbTitle.Name = "cbTitle";
            this.cbTitle.Size = new System.Drawing.Size(196, 24);
            this.cbTitle.TabIndex = 30;
            // 
            // CbGender
            // 
            this.CbGender.FormattingEnabled = true;
            this.CbGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other "});
            this.CbGender.Location = new System.Drawing.Point(530, 118);
            this.CbGender.Name = "CbGender";
            this.CbGender.Size = new System.Drawing.Size(196, 24);
            this.CbGender.TabIndex = 29;
            // 
            // gbContactInfromation
            // 
            this.gbContactInfromation.Controls.Add(this.lblerror);
            this.gbContactInfromation.Controls.Add(this.lblemail);
            this.gbContactInfromation.Controls.Add(this.txtEmail);
            this.gbContactInfromation.Controls.Add(this.lblCellphone);
            this.gbContactInfromation.Controls.Add(this.txtCellPhoneNumber);
            this.gbContactInfromation.Location = new System.Drawing.Point(1054, 152);
            this.gbContactInfromation.Name = "gbContactInfromation";
            this.gbContactInfromation.Size = new System.Drawing.Size(730, 216);
            this.gbContactInfromation.TabIndex = 21;
            this.gbContactInfromation.TabStop = false;
            this.gbContactInfromation.Text = "Contact Infromation";
            // 
            // lblerror
            // 
            this.lblerror.AutoSize = true;
            this.lblerror.ForeColor = System.Drawing.Color.Red;
            this.lblerror.Location = new System.Drawing.Point(6, 169);
            this.lblerror.Name = "lblerror";
            this.lblerror.Size = new System.Drawing.Size(35, 16);
            this.lblerror.TabIndex = 20;
            this.lblerror.Text = "error";
            this.lblerror.Visible = false;
            // 
            // GbPhysicalAdress
            // 
            this.GbPhysicalAdress.Controls.Add(this.cbProvince);
            this.GbPhysicalAdress.Controls.Add(this.lblPostalcode);
            this.GbPhysicalAdress.Controls.Add(this.txtPostalCode);
            this.GbPhysicalAdress.Controls.Add(this.lblSurburb);
            this.GbPhysicalAdress.Controls.Add(this.txtSurburb);
            this.GbPhysicalAdress.Controls.Add(this.lblProvicnce);
            this.GbPhysicalAdress.Controls.Add(this.lblhousenumber);
            this.GbPhysicalAdress.Controls.Add(this.txtHouseNumber);
            this.GbPhysicalAdress.Controls.Add(this.lblStreetname);
            this.GbPhysicalAdress.Controls.Add(this.txtStreetName);
            this.GbPhysicalAdress.Location = new System.Drawing.Point(142, 582);
            this.GbPhysicalAdress.Name = "GbPhysicalAdress";
            this.GbPhysicalAdress.Size = new System.Drawing.Size(875, 308);
            this.GbPhysicalAdress.TabIndex = 22;
            this.GbPhysicalAdress.TabStop = false;
            this.GbPhysicalAdress.Text = "Physical Adress";
            // 
            // cbProvince
            // 
            this.cbProvince.FormattingEnabled = true;
            this.cbProvince.Items.AddRange(new object[] {
            "Gauteng",
            "Free State",
            "Western Cape",
            "Northern Cape",
            "Eastern Cape",
            "Kwa-Zulu Natal",
            "Mpumalanga",
            "Limpopo",
            "North West"});
            this.cbProvince.Location = new System.Drawing.Point(530, 205);
            this.cbProvince.Name = "cbProvince";
            this.cbProvince.Size = new System.Drawing.Size(196, 24);
            this.cbProvince.TabIndex = 28;
            // 
            // lblPostalcode
            // 
            this.lblPostalcode.AutoSize = true;
            this.lblPostalcode.Location = new System.Drawing.Point(20, 252);
            this.lblPostalcode.Name = "lblPostalcode";
            this.lblPostalcode.Size = new System.Drawing.Size(79, 16);
            this.lblPostalcode.TabIndex = 26;
            this.lblPostalcode.Text = "Postal code";
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(530, 252);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(196, 22);
            this.txtPostalCode.TabIndex = 27;
            // 
            // lblSurburb
            // 
            this.lblSurburb.AutoSize = true;
            this.lblSurburb.Location = new System.Drawing.Point(21, 144);
            this.lblSurburb.Name = "lblSurburb";
            this.lblSurburb.Size = new System.Drawing.Size(91, 16);
            this.lblSurburb.TabIndex = 24;
            this.lblSurburb.Text = "Surburb/Town";
            // 
            // txtSurburb
            // 
            this.txtSurburb.Location = new System.Drawing.Point(531, 144);
            this.txtSurburb.Name = "txtSurburb";
            this.txtSurburb.Size = new System.Drawing.Size(196, 22);
            this.txtSurburb.TabIndex = 25;
            // 
            // lblProvicnce
            // 
            this.lblProvicnce.AutoSize = true;
            this.lblProvicnce.Location = new System.Drawing.Point(21, 205);
            this.lblProvicnce.Name = "lblProvicnce";
            this.lblProvicnce.Size = new System.Drawing.Size(60, 16);
            this.lblProvicnce.TabIndex = 22;
            this.lblProvicnce.Text = "Province";
            // 
            // lblhousenumber
            // 
            this.lblhousenumber.AutoSize = true;
            this.lblhousenumber.Location = new System.Drawing.Point(21, 32);
            this.lblhousenumber.Name = "lblhousenumber";
            this.lblhousenumber.Size = new System.Drawing.Size(92, 16);
            this.lblhousenumber.TabIndex = 20;
            this.lblhousenumber.Text = "house number";
            this.lblhousenumber.Click += new System.EventHandler(this.lblhousenumber_Click);
            // 
            // txtHouseNumber
            // 
            this.txtHouseNumber.Location = new System.Drawing.Point(530, 29);
            this.txtHouseNumber.Name = "txtHouseNumber";
            this.txtHouseNumber.Size = new System.Drawing.Size(196, 22);
            this.txtHouseNumber.TabIndex = 21;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(1054, 593);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(730, 308);
            this.listBox1.TabIndex = 23;
            // 
            // BtnRegister
            // 
            this.BtnRegister.Location = new System.Drawing.Point(1553, 923);
            this.BtnRegister.Name = "BtnRegister";
            this.BtnRegister.Size = new System.Drawing.Size(231, 61);
            this.BtnRegister.TabIndex = 24;
            this.BtnRegister.Text = "Register";
            this.BtnRegister.UseVisualStyleBackColor = true;
            this.BtnRegister.Click += new System.EventHandler(this.BtnRegister_Click);
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(1302, 923);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(231, 61);
            this.BtnBack.TabIndex = 25;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // gbLoginInfromation
            // 
            this.gbLoginInfromation.Controls.Add(this.lblConfirmPassword);
            this.gbLoginInfromation.Controls.Add(this.txtConfirmPassword);
            this.gbLoginInfromation.Controls.Add(this.lblIDNumber);
            this.gbLoginInfromation.Controls.Add(this.txtIDNumber);
            this.gbLoginInfromation.Controls.Add(this.LblPassword);
            this.gbLoginInfromation.Controls.Add(this.txtPassword);
            this.gbLoginInfromation.Location = new System.Drawing.Point(1054, 376);
            this.gbLoginInfromation.Name = "gbLoginInfromation";
            this.gbLoginInfromation.Size = new System.Drawing.Size(730, 200);
            this.gbLoginInfromation.TabIndex = 22;
            this.gbLoginInfromation.TabStop = false;
            this.gbLoginInfromation.Text = "Login Infromation";
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Location = new System.Drawing.Point(6, 139);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(118, 16);
            this.lblConfirmPassword.TabIndex = 18;
            this.lblConfirmPassword.Text = "Confirm Password:";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(514, 133);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(196, 22);
            this.txtConfirmPassword.TabIndex = 19;
            // 
            // lblIDNumber
            // 
            this.lblIDNumber.AutoSize = true;
            this.lblIDNumber.Location = new System.Drawing.Point(6, 49);
            this.lblIDNumber.Name = "lblIDNumber";
            this.lblIDNumber.Size = new System.Drawing.Size(74, 16);
            this.lblIDNumber.TabIndex = 14;
            this.lblIDNumber.Text = "ID Number:";
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.Location = new System.Drawing.Point(514, 43);
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(196, 22);
            this.txtIDNumber.TabIndex = 15;
            this.txtIDNumber.TextChanged += new System.EventHandler(this.txtIDNumber_TextChanged);
            // 
            // LblPassword
            // 
            this.LblPassword.AutoSize = true;
            this.LblPassword.Location = new System.Drawing.Point(6, 94);
            this.LblPassword.Name = "LblPassword";
            this.LblPassword.Size = new System.Drawing.Size(70, 16);
            this.LblPassword.TabIndex = 16;
            this.LblPassword.Text = "Password:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(514, 88);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(196, 22);
            this.txtPassword.TabIndex = 17;
            // 
            // BtnConfirm
            // 
            this.BtnConfirm.Location = new System.Drawing.Point(1553, 923);
            this.BtnConfirm.Name = "BtnConfirm";
            this.BtnConfirm.Size = new System.Drawing.Size(231, 61);
            this.BtnConfirm.TabIndex = 26;
            this.BtnConfirm.Text = "Confirm";
            this.BtnConfirm.UseVisualStyleBackColor = true;
            this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
            // 
            // RegisterPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.BtnConfirm);
            this.Controls.Add(this.gbLoginInfromation);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.BtnRegister);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.GbPhysicalAdress);
            this.Controls.Add(this.gbContactInfromation);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "RegisterPage";
            this.Text = "RegisterPage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.RegisterPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbContactInfromation.ResumeLayout(false);
            this.gbContactInfromation.PerformLayout();
            this.GbPhysicalAdress.ResumeLayout(false);
            this.GbPhysicalAdress.PerformLayout();
            this.gbLoginInfromation.ResumeLayout(false);
            this.gbLoginInfromation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblCellphone;
        private System.Windows.Forms.TextBox txtCellPhoneNumber;
        private System.Windows.Forms.Label lblStreetname;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox gbContactInfromation;
        private System.Windows.Forms.GroupBox GbPhysicalAdress;
        private System.Windows.Forms.Label lblhousenumber;
        private System.Windows.Forms.TextBox txtHouseNumber;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button BtnRegister;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Label lblSurburb;
        private System.Windows.Forms.TextBox txtSurburb;
        private System.Windows.Forms.Label lblProvicnce;
        private System.Windows.Forms.ComboBox cbProvince;
        private System.Windows.Forms.Label lblPostalcode;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.ComboBox cbTitle;
        private System.Windows.Forms.ComboBox CbGender;
        private System.Windows.Forms.GroupBox gbLoginInfromation;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label lblIDNumber;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.Label LblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button BtnConfirm;
        private System.Windows.Forms.Label lblerror;
    }
}