﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group23Project_IndependentVotingCommision.Properties
{
    public partial class RegisterPage : Form
    {
        //remember to put in vote in the vote database
        public string IDNumber = "", firstName = "", middleName = "", lastName = "", gender = "", title = "", StreetName = "", Surburb = "", Province = "", PostalCode = "", emailAdress = "", CellNumber = "";

        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {
            string idNumber = txtIDNumber.Text;

            if (idNumber.Length >= 2 && int.TryParse(idNumber.Substring(0, 2), out int birthYearFirstTwoDigits))
            {
                int birthYear = 2000 + birthYearFirstTwoDigits; // Assuming the ID contains a two-digit year (e.g., YY)
                int age = CalculateAge(birthYear);

                if (age >= 18 && idNumber.Length==13)
                {
                    txtIDNumber.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    txtIDNumber.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
            private int CalculateAge(int birthYear)
            {
                int currentYear = DateTime.Today.Year;
                int age = currentYear - birthYear;

                return age;
            }
        

        private void txtCellPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            //validate contact number

            string inputNumber = txtCellPhoneNumber.Text.Trim();

            string pattern = @"^\+27\d{9}$";

            if(Regex.IsMatch(inputNumber,pattern))
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                txtCellPhoneNumber.ForeColor = System.Drawing.Color.Red;
            }
        }
        public RegisterPage()
        {
            InitializeComponent();
            txtCellPhoneNumber.TextChanged += txtCellPhoneNumber_TextChanged;
        }

        public int houseNumber = 0;
        public string Password = "";

        public string chosenLanguage;
        public RegisterPage(string language)
        {
            InitializeComponent();
            chosenLanguage = language;
            
        }

       

        private void BtnBack_Click(object sender, EventArgs e)
        {
            frmWelcomePage welcomePage = new frmWelcomePage();
            welcomePage.ShowDialog();
            this.Hide();
            chosenLanguage = "";
            listBox1.Items.Clear();

            //hide forms


        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            
            listBox1.Items.Clear();
            MessageBox.Show("You have successfully registered");
            LoginPage loginPage = new LoginPage();
            loginPage.ShowDialog();
            
        }


        
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //store textbox values in the variables
                int.TryParse(txtHouseNumber.Text, out houseNumber);
                IDNumber = txtIDNumber.Text;
                firstName = txtFirstName.Text;
                lastName = txtLastName.Text;
                middleName = txtMiddleName.Text;
                StreetName = txtStreetName.Text;
                Surburb = txtSurburb.Text;
                Province = cbProvince.Text;
                PostalCode = txtPostalCode.Text;
                emailAdress = txtEmail.Text;
                CellNumber = txtCellPhoneNumber.Text;
                title = cbTitle.Text;
                gender = CbGender.Text;
                Password = txtPassword.Text;

                //list box showing the users details
                listBox1.Items.Add("Your details are as follows");
                listBox1.Items.Add(" ");
                listBox1.Items.Add("Title:" + "\t" + title);
                listBox1.Items.Add("Gender:" + "\t" + gender);
                listBox1.Items.Add("ID Number: " + "\t" + IDNumber);
                listBox1.Items.Add("First name: " + "\t" + firstName);
                listBox1.Items.Add("Middle name: " + "\t" + middleName);
                listBox1.Items.Add("Last name: " + "\t" + lastName);
                listBox1.Items.Add("House Number: " + "\t" + houseNumber);
                listBox1.Items.Add("Street Name: " + "\t" + StreetName);
                listBox1.Items.Add("Surburb: " + "\t" + Surburb);
                listBox1.Items.Add("Province: " + "\t" + Province);
                listBox1.Items.Add("Postal Code: " + "\t" + PostalCode);
                listBox1.Items.Add("Email Address:" + "\t" + emailAdress);
                listBox1.Items.Add("Cellphone Number: " + "\t" + CellNumber);

                if (txtConfirmPassword.Text != txtPassword.Text)
                {
                    MessageBox.Show("The passwords do not match!");
                    txtPassword.Text = " ";
                    txtConfirmPassword.Text = " ";
                }
                else if (txtPassword.TextLength < 8)
                {
                    MessageBox.Show("Password is less than 8 characters");
                }
                else
                {
                    BtnConfirm.Visible = true;
                    BtnRegister.Visible = false;
                }

            }
            catch (Exception ex)
            { 
                //if theres an error in the code we will know what the error is because it will be shown in a message box
                MessageBox.Show(ex.Message);
            }
            

        }

        
        

        
       

        

        private void RegisterPage_Load(object sender, EventArgs e)
        {
            BtnConfirm.Visible = false;

            //sesotho language 
            if(chosenLanguage == "sesotho")
            {
                lblheading.Text = "IVC LEPHEPHE LA NGODISO";

                groupBox1.Text = "disntla tse di amanang le uena";
                lbltitle.Text = "Sehlooho:";
                lblGender.Text = "Bong";
                lblFirstName.Text = "Lebitso la Pele: ";
                lblLastName.Text = "fane";
                lblMiddleName.Text = "Lebitso la Gare:";

                gbContactInfromation.Text = "Aterese ea Sebaka";
                lblStreetname.Text = "Nomoro ea Ntlo:";
                lblStreetname.Text = "Lebisto la seterata:";
                lblSurburb.Text = "Toropo:";
                lblProvicnce.Text = "Profinse:";
                lblPostalcode.Text = "Nomora ea Poso:";

                gbContactInfromation.Text = "Dintlha tsa mohala";
                lblemail.Text = "Aterese ea Imeile:";
                lblCellphone.Text = "Nomoro ea Mohala(+27):";

                GbPhysicalAdress.Text = "Dintlha tsa ho kena";
                lblIDNumber.Text = "Nomoro ea ID:";
                LblPassword.Text = "Phasewete";
                lblConfirmPassword.Text = "Netefatsa Phasewete";

                BtnBack.Text = "morao";
                BtnRegister.Text = "ngodisa";
            }
            else if(chosenLanguage == "afrikaans")
            {

            }
            else{

            }
        }
    }
}
