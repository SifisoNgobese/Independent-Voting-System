﻿namespace Group23Project_IndependentVotingCommision
{
    partial class frmWelcomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLanguageChosen = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioAfrikaans = new System.Windows.Forms.RadioButton();
            this.radioEnglish = new System.Windows.Forms.RadioButton();
            this.radioSesotho = new System.Windows.Forms.RadioButton();
            this.cbTermsAndConditions = new System.Windows.Forms.CheckBox();
            this.btnRegister2 = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblTranslate = new System.Windows.Forms.Label();
            this.lblWelcomePageText = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioZulu = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1207, 303);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(430, 326);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1142, 134);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(519, 91);
            this.label3.TabIndex = 39;
            this.label3.Text = "COMMISION";
            // 
            // lblLanguageChosen
            // 
            this.lblLanguageChosen.AutoSize = true;
            this.lblLanguageChosen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguageChosen.Location = new System.Drawing.Point(30, 655);
            this.lblLanguageChosen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLanguageChosen.Name = "lblLanguageChosen";
            this.lblLanguageChosen.Size = new System.Drawing.Size(53, 20);
            this.lblLanguageChosen.TabIndex = 34;
            this.lblLanguageChosen.Text = "label6";
            this.lblLanguageChosen.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.SeaGreen;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 24;
            this.listBox1.Location = new System.Drawing.Point(17, 87);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(659, 316);
            this.listBox1.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(159, 36);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(332, 29);
            this.label4.TabIndex = 32;
            this.label4.Text = "TERMS AND CONDITIONS";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.lblLanguageChosen);
            this.panel2.Controls.Add(this.listBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.cbTermsAndConditions);
            this.panel2.Controls.Add(this.btnRegister2);
            this.panel2.Controls.Add(this.btnLogin);
            this.panel2.Location = new System.Drawing.Point(-1, -6);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(716, 1067);
            this.panel2.TabIndex = 38;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioZulu);
            this.groupBox1.Controls.Add(this.radioAfrikaans);
            this.groupBox1.Controls.Add(this.radioEnglish);
            this.groupBox1.Controls.Add(this.radioSesotho);
            this.groupBox1.Location = new System.Drawing.Point(28, 430);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(627, 222);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose a language";
            // 
            // radioAfrikaans
            // 
            this.radioAfrikaans.AutoSize = true;
            this.radioAfrikaans.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.radioAfrikaans.Location = new System.Drawing.Point(6, 122);
            this.radioAfrikaans.Name = "radioAfrikaans";
            this.radioAfrikaans.Size = new System.Drawing.Size(180, 43);
            this.radioAfrikaans.TabIndex = 41;
            this.radioAfrikaans.TabStop = true;
            this.radioAfrikaans.Text = "Afrikaans";
            this.radioAfrikaans.UseVisualStyleBackColor = true;
            this.radioAfrikaans.CheckedChanged += new System.EventHandler(this.radioAfrikaans_CheckedChanged);
            // 
            // radioEnglish
            // 
            this.radioEnglish.AutoSize = true;
            this.radioEnglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.radioEnglish.Location = new System.Drawing.Point(6, 32);
            this.radioEnglish.Name = "radioEnglish";
            this.radioEnglish.Size = new System.Drawing.Size(151, 43);
            this.radioEnglish.TabIndex = 39;
            this.radioEnglish.TabStop = true;
            this.radioEnglish.Text = "English";
            this.radioEnglish.UseVisualStyleBackColor = true;
            this.radioEnglish.CheckedChanged += new System.EventHandler(this.radioEnglish_CheckedChanged);
            // 
            // radioSesotho
            // 
            this.radioSesotho.AutoSize = true;
            this.radioSesotho.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.radioSesotho.Location = new System.Drawing.Point(6, 73);
            this.radioSesotho.Name = "radioSesotho";
            this.radioSesotho.Size = new System.Drawing.Size(163, 43);
            this.radioSesotho.TabIndex = 40;
            this.radioSesotho.TabStop = true;
            this.radioSesotho.Text = "Sesotho";
            this.radioSesotho.UseVisualStyleBackColor = true;
            this.radioSesotho.CheckedChanged += new System.EventHandler(this.radioSesotho_CheckedChanged);
            // 
            // cbTermsAndConditions
            // 
            this.cbTermsAndConditions.AutoSize = true;
            this.cbTermsAndConditions.Location = new System.Drawing.Point(28, 697);
            this.cbTermsAndConditions.Margin = new System.Windows.Forms.Padding(4);
            this.cbTermsAndConditions.Name = "cbTermsAndConditions";
            this.cbTermsAndConditions.Size = new System.Drawing.Size(390, 20);
            this.cbTermsAndConditions.TabIndex = 29;
            this.cbTermsAndConditions.Text = "i agree to accept the terms and conditions before proceeding";
            this.cbTermsAndConditions.UseVisualStyleBackColor = true;
            this.cbTermsAndConditions.CheckedChanged += new System.EventHandler(this.cbTermsAndConditions_CheckedChanged);
            // 
            // btnRegister2
            // 
            this.btnRegister2.BackColor = System.Drawing.Color.SeaGreen;
            this.btnRegister2.Enabled = false;
            this.btnRegister2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRegister2.Location = new System.Drawing.Point(15, 737);
            this.btnRegister2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRegister2.Name = "btnRegister2";
            this.btnRegister2.Size = new System.Drawing.Size(339, 58);
            this.btnRegister2.TabIndex = 1;
            this.btnRegister2.Text = "Register";
            this.btnRegister2.UseVisualStyleBackColor = false;
            this.btnRegister2.Click += new System.EventHandler(this.btnRegister2_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.SeaGreen;
            this.btnLogin.Enabled = false;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLogin.Location = new System.Drawing.Point(360, 737);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(338, 58);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblTranslate
            // 
            this.lblTranslate.AutoSize = true;
            this.lblTranslate.Location = new System.Drawing.Point(230, 715);
            this.lblTranslate.Name = "lblTranslate";
            this.lblTranslate.Size = new System.Drawing.Size(44, 16);
            this.lblTranslate.TabIndex = 37;
            this.lblTranslate.Text = "label1";
            // 
            // lblWelcomePageText
            // 
            this.lblWelcomePageText.AutoSize = true;
            this.lblWelcomePageText.Font = new System.Drawing.Font("Lucida Handwriting", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomePageText.ForeColor = System.Drawing.Color.White;
            this.lblWelcomePageText.Location = new System.Drawing.Point(1025, 715);
            this.lblWelcomePageText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcomePageText.Name = "lblWelcomePageText";
            this.lblWelcomePageText.Size = new System.Drawing.Size(682, 104);
            this.lblWelcomePageText.TabIndex = 40;
            this.lblWelcomePageText.Text = "Welcome Page";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(923, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(957, 91);
            this.label2.TabIndex = 36;
            this.label2.Text = "INDEPENDENT VOTING";
            // 
            // radioZulu
            // 
            this.radioZulu.AutoSize = true;
            this.radioZulu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.radioZulu.Location = new System.Drawing.Point(6, 171);
            this.radioZulu.Name = "radioZulu";
            this.radioZulu.Size = new System.Drawing.Size(138, 43);
            this.radioZulu.TabIndex = 42;
            this.radioZulu.TabStop = true;
            this.radioZulu.Text = "isiZulu";
            this.radioZulu.UseVisualStyleBackColor = true;
            this.radioZulu.CheckedChanged += new System.EventHandler(this.radioZulu_CheckedChanged);
            // 
            // frmWelcomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblTranslate);
            this.Controls.Add(this.lblWelcomePageText);
            this.Controls.Add(this.label2);
            this.Name = "frmWelcomePage";
            this.Text = "Welcome Page";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmWelcomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLanguageChosen;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox cbTermsAndConditions;
        private System.Windows.Forms.Button btnRegister2;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblTranslate;
        private System.Windows.Forms.Label lblWelcomePageText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioAfrikaans;
        private System.Windows.Forms.RadioButton radioEnglish;
        private System.Windows.Forms.RadioButton radioSesotho;
        private System.Windows.Forms.RadioButton radioZulu;
    }
}

